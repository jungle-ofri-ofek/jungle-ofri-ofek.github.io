package com.jungle.ofriofek;
import android.app.Activity;import android.appwidget.AppWidgetManager;import android.content.*;import android.net.Uri;import android.os.Bundle;import android.widget.TextView;
public class MainActivity extends Activity {
 TextView current;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);current=findViewById(R.id.currentWaterer);findViewById(R.id.chooseOfek).setOnClickListener(v->choose("אופק"));findViewById(R.id.chooseOfri).setOnClickListener(v->choose("עופרי"));findViewById(R.id.openSite).setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://jungle-ofri-ofek.github.io/"))));show();}
 void choose(String by){getSharedPreferences("settings",0).edit().putString("waterer",by).apply();show();sendBroadcast(new Intent(this,PlantWidget.class).setAction(PlantWidget.REFRESH));}
 void show(){current.setText("כרגע: "+getSharedPreferences("settings",0).getString("waterer","אופק"));}
}
