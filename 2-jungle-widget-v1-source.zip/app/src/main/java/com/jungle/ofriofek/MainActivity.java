package com.jungle.ofriofek;
import android.app.Activity;import android.os.Bundle;import android.content.Intent;import android.net.Uri;import android.widget.Button;
public class MainActivity extends Activity { public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);findViewById(R.id.openSite).setOnClickListener(v->startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://jungle-ofri-ofek.github.io/"))));} }
